var $ = require("jquery"), YASGUI = require("./main.js");
var root = module.exports = require("yasgui-yasr");
