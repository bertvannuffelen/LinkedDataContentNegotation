//extend jquery
require("jquery-ui/resizable.js");
require("./outsideclick.js");
require("./tab.js");
require("./endpointCombi.js");
require("jquery-ui/position");
require("jquery-ui/sortable");
