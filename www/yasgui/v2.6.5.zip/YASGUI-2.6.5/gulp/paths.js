module.exports = {
  yasqe: "node_modules/yasgui-yasqe/",
  yasr: "node_modules/yasgui-yasr/",
  style: ["src/scss/scoped.scss", "src/scss/global.scss"],
  bundleDir: "dist",
  bundleName: "yasgui",
  docDir: "doc"
};
